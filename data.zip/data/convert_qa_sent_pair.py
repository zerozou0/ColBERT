import random

import pandas as pd
import pdb


id_1 = 0
sent_1_id = dict()  # will become queries_tsv
id_2 = 0
sent_2_id = dict()  # will become collections_tsv
triples_dict = dict()  # {id_1: {"similar": [id2], "dissimilar": [...]}}

cols = ['sentence1', 'sentence2', 'label']
# df = pd.read_json('s3://csml-gluon-egress-bucket-beta-na/qa/data_with_body.json', orient='records', lines=False)
df = pd.read_json('/home/yid/yid-efs/ColBERT/data/data_with_body.json', orient='records', lines=False)

n_skipped = 0
for i, r in df.iterrows():
    if (not r.sentence1) or (not r.sentence2):
        n_skipped += 1
        continue

    if r.sentence1 not in sent_1_id:
        sent_1_id[r.sentence1] = id_1
        id_1 += 1
    if r.sentence2 not in sent_2_id:
        sent_2_id[r.sentence2] = id_2
        id_2 += 1
    
    qid = sent_1_id[r.sentence1]
    pid = sent_2_id[r.sentence2]
    if qid not in triples_dict:
        triples_dict[qid] = {'similar': [], 'dissimilar': []}
    if r.label == 'similar':
        triples_dict[qid]['similar'].append(pid)
    else:
        triples_dict[qid]['dissimilar'].append(pid)
print(f'Skipped {n_skipped} incomplete examples (empty query or doc)')

print('Converting to triples list')
triples = []
n_skipped = 0
for qid, d in triples_dict.items():
    n_similar = len(d['similar'])
    if n_similar == 0:
        n_skipped += 1
        continue
    for pid_n in d['dissimilar']:
        pid_p = d['similar'][
            0 if n_similar == 1 else
            random.randint(0, n_similar - 1)
        ]
        triples.append({'qid': qid, 'pid_p': pid_p, 'pid_n': pid_n})
print(f"Skipped {n_skipped} examples that don't have a hard-positive")

print('Writing data to tsv')
queries_tsv = pd.DataFrame(list(sent_1_id.items())).rename(
    columns={0: 'query_text', 1: 'qid'}
)[['qid', 'query_text']]
queries_tsv.query_text = queries_tsv.query_text.apply(lambda s: '[Q] ' + s.replace('\n', ' '))  # No line breaks
queries_tsv.to_csv('/home/yid/yid-efs/ColBERT/data/queries_mpnet_231127.tsv', sep='\t', header=False, index=False)

collections_tsv = pd.DataFrame(list(sent_2_id.items())).rename(
    columns={0: 'doc_text', 1: 'pid'}
)[['pid', 'doc_text']]
collections_tsv.doc_text = collections_tsv.doc_text.apply(lambda s: '[D] ' + s.replace('\n', ' '))  # No line breaks
collections_tsv.to_csv(
    '/home/yid/yid-efs/ColBERT/data/collections_mpnet_231127.tsv', sep='\t', header=False, index=False
)

triples_df = pd.DataFrame(triples).sample(frac=1.0)
with open('/home/yid/yid-efs/ColBERT/data/triples_mpnet_231127.tsv', 'w+') as triples_jsonl_file:
    for i, r in triples_df.iterrows():
        triples_jsonl_file.write(f'[{r.qid}, {r.pid_p}, {r.pid_n}]\n')

pdb.set_trace()
