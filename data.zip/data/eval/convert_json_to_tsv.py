import json
from typing import Dict, List

import pandas as pd


ROOT = '/home/yid/yid-efs/ColBERT'
QUERIES_FNAME = 'ir_test_data.json'
ARTICLES_FNAME = 'nodeid2claudesummary_231122.json'

with open(f'{ROOT}/data/eval/{ARTICLES_FNAME}', 'r') as f:
    nodeid2claudesummary: Dict[str, str] = json.load(f)

pid = 0
nodeid2pid = dict()
with open(f'{ROOT}/data/eval/{".".join(ARTICLES_FNAME.split(".")[:-1])}.tsv', 'w+') as f:
    for nodeid, doc in nodeid2claudesummary.items():
        if nodeid in nodeid2pid:
            continue
        nodeid2pid[nodeid] = pid
        f.write(str(pid) + '\t[D] ' + doc.replace("\n", "  ") + '\n')  # No line breaks
        pid += 1
nodeid2pid_df = pd.DataFrame(list(nodeid2pid.items())).rename(
    columns={0: 'nodeid', 1: 'pid'}
)
nodeid2pid_df.to_json(f'{ROOT}/data/eval/nodeid2pid_{ARTICLES_FNAME}', orient='records')

with open(f'{ROOT}/data/eval/{QUERIES_FNAME}', 'r') as f:
    test_data: List[Dict[str, str]] = json.load(f)

qid = 0
test_queries = dict()
qid2gt = dict()
for ex in test_data:
    if ex['query'] in test_queries:
        continue
    test_queries[ex['query']] = qid
    qid2gt[qid] = ex['nodeid']
    qid += 1

queries_tsv = pd.DataFrame(list(test_queries.items())).rename(
    columns={0: 'query_text', 1: 'qid'}
)[['qid', 'query_text']]
queries_tsv.query_text = queries_tsv.query_text.apply(lambda s: '[Q] ' + s.replace('\n', ' '))  # No line breaks
queries_tsv.to_csv(f'{ROOT}/data/eval/queries_ir_test_data.tsv', sep='\t', header=False, index=False)

pd.DataFrame(list(qid2gt.items())).rename(
    columns={0: 'qid', 1: 'nodeid'}
).to_json(f'{ROOT}/data/eval/qid2gt_ir_test_data.json', orient='records')
